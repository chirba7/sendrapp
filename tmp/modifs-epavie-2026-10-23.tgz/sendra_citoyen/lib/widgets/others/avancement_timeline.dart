import 'package:flutter/material.dart';

import '../../utils/sendra_theme.dart';

/// Une étape de l'avancement d'un signalement.
class EtapeAvancement {
  const EtapeAvancement({
    required this.etat,
    required this.libelle,
    required this.statut,
    this.detail,
    this.date,
  });

  /// SIGNALE, EN COURS, ENLEVE, NON RESOLU ou REJETE.
  final String etat;
  final String libelle;

  /// fait, actuel, a_venir ou saute.
  final String statut;
  final String? detail;
  final String? date;

  bool get atteinte => statut == 'fait' || statut == 'actuel';

  /// Étapes envoyées par le serveur (`avancement`), ou à défaut déduites de
  /// l'état seul (anciennes réponses, signalements des autres hors ligne).
  static List<EtapeAvancement> depuis(Map<String, dynamic> data) {
    final brut = data['avancement'];
    if (brut is List && brut.isNotEmpty) {
      return [
        for (final e in brut)
          if (e is Map)
            EtapeAvancement(
              etat: e['etat']?.toString() ?? '',
              libelle: e['libelle']?.toString() ?? '',
              statut: e['statut']?.toString() ?? 'a_venir',
              detail: e['detail']?.toString(),
              date: e['date']?.toString(),
            ),
      ];
    }

    final etat = data['etat']?.toString() ?? 'SIGNALE';
    final clos = etat == 'ENLEVE' || etat == 'NON RESOLU' || etat == 'REJETE';
    final enCours = etat == 'EN COURS' || etat == 'ENLEVE' || etat == 'NON RESOLU';
    final issue = clos ? etat : 'ENLEVE';
    return [
      EtapeAvancement(
        etat: 'SIGNALE',
        libelle: 'Signalé',
        statut: enCours || clos ? 'fait' : 'actuel',
        detail: 'Signalement reçu',
        date: data['formatted_date']?.toString(),
      ),
      EtapeAvancement(
        etat: 'EN COURS',
        libelle: 'En cours',
        statut: clos ? (enCours ? 'fait' : 'saute') : (enCours ? 'actuel' : 'a_venir'),
        detail: 'Approuvé, enlèvement à venir',
      ),
      EtapeAvancement(
        etat: issue,
        libelle: SendraTheme.status(issue).label,
        statut: clos ? 'fait' : 'a_venir',
        detail: switch (etat) {
          'REJETE' => data['motif_approbation']?.toString() ?? 'Refusé par l’autorité',
          'NON RESOLU' => data['non_removal_reason']?.toString() ?? 'Véhicule non enlevé',
          'ENLEVE' => 'Véhicule enlevé',
          _ => 'Enlèvement du véhicule',
        },
      ),
    ];
  }
}

/// Frise verticale de l'avancement : une pastille par état, reliées par un
/// rail vertical qui se remplit (glisse) jusqu'à l'étape atteinte.
class AvancementTimeline extends StatelessWidget {
  const AvancementTimeline({super.key, required this.data, this.titre = 'Avancement du signalement'});

  final Map<String, dynamic> data;
  final String titre;

  @override
  Widget build(BuildContext context) {
    final etapes = EtapeAvancement.depuis(data);
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: SendraTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(titre,
              style: const TextStyle(
                  fontSize: 17, fontWeight: FontWeight.w800, color: SendraTheme.ink)),
          const SizedBox(height: 14),
          for (var i = 0; i < etapes.length; i++)
            _LigneEtape(
              etape: etapes[i],
              index: i,
              derniere: i == etapes.length - 1,
              // Le rail sous une étape se remplit si l'étape suivante est
              // atteinte (ou sautée, quand le dossier est clos plus loin).
              railRempli: i < etapes.length - 1 &&
                  (etapes[i + 1].atteinte ||
                      (etapes[i + 1].statut == 'saute' &&
                          i + 2 < etapes.length &&
                          etapes[i + 2].atteinte)),
              // Le rail prend la couleur de l'étape vers laquelle il mène.
              couleurRail: i < etapes.length - 1
                  ? SendraTheme.status(etapes[i + 1].statut == 'saute' &&
                              i + 2 < etapes.length
                          ? etapes[i + 2].etat
                          : etapes[i + 1].etat)
                      .color
                  : SendraTheme.border,
            ),
        ],
      ),
    );
  }
}

class _LigneEtape extends StatelessWidget {
  const _LigneEtape({
    required this.etape,
    required this.index,
    required this.derniere,
    required this.railRempli,
    required this.couleurRail,
  });

  final EtapeAvancement etape;
  final int index;
  final bool derniere;
  final bool railRempli;
  final Color couleurRail;

  @override
  Widget build(BuildContext context) {
    final style = SendraTheme.status(etape.etat);
    final saute = etape.statut == 'saute';
    final atteinte = etape.atteinte;
    final actuelle = etape.statut == 'actuel';
    final couleur = atteinte ? style.color : SendraTheme.border;

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            width: 34,
            child: Column(
              children: [
                // Pastille de l'étape.
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: atteinte ? style.color : Colors.white,
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: saute ? SendraTheme.border : couleur, width: 2),
                    boxShadow: actuelle
                        ? [
                            BoxShadow(
                              color: style.color.withValues(alpha: .28),
                              blurRadius: 0,
                              spreadRadius: 5,
                            )
                          ]
                        : null,
                  ),
                  child: Icon(
                    saute
                        ? Icons.remove_rounded
                        : etape.statut == 'fait'
                            ? (etape.etat == 'REJETE' || etape.etat == 'NON RESOLU'
                                ? style.icon
                                : Icons.check_rounded)
                            : style.icon,
                    size: 17,
                    color: atteinte ? Colors.white : SendraTheme.muted,
                  ),
                ),
                if (!derniere)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: _Rail(rempli: railRempli, couleur: couleurRail, delai: index),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(top: 4, bottom: derniere ? 8 : 22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          etape.libelle,
                          style: TextStyle(
                            fontSize: 15.5,
                            fontWeight: actuelle ? FontWeight.w800 : FontWeight.w700,
                            color: atteinte ? SendraTheme.ink : SendraTheme.muted,
                            decoration: saute ? TextDecoration.lineThrough : null,
                          ),
                        ),
                      ),
                      if (actuelle) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(
                            color: style.color.withValues(alpha: .12),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text('Étape actuelle',
                              style: TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  color: style.color)),
                        ),
                      ],
                    ],
                  ),
                  if (!saute && (etape.detail ?? '').isNotEmpty) ...[
                    const SizedBox(height: 3),
                    Text(etape.detail!,
                        style: const TextStyle(
                            color: SendraTheme.muted, fontSize: 13.5, height: 1.35)),
                  ],
                  if (saute)
                    const Padding(
                      padding: EdgeInsets.only(top: 3),
                      child: Text('Étape non atteinte',
                          style: TextStyle(color: SendraTheme.muted, fontSize: 13)),
                    ),
                  if (atteinte && (etape.date ?? '').isNotEmpty) ...[
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        const Icon(Icons.schedule_rounded,
                            size: 14, color: SendraTheme.muted),
                        const SizedBox(width: 4),
                        Flexible(
                          child: Text(etape.date!,
                              style: const TextStyle(
                                  color: SendraTheme.muted, fontSize: 12.5)),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Rail vertical entre deux étapes : se remplit de haut en bas à l'affichage.
class _Rail extends StatelessWidget {
  const _Rail({required this.rempli, required this.couleur, required this.delai});
  final bool rempli;
  final Color couleur;
  final int delai;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 4,
      decoration: BoxDecoration(
        color: SendraTheme.border,
        borderRadius: BorderRadius.circular(2),
      ),
      alignment: Alignment.topCenter,
      child: rempli
          ? TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: 1),
              duration: Duration(milliseconds: 450 + 250 * delai),
              curve: Curves.easeOutCubic,
              builder: (context, t, _) => FractionallySizedBox(
                heightFactor: t,
                alignment: Alignment.topCenter,
                child: Container(
                  width: 4,
                  decoration: BoxDecoration(
                    color: couleur,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
            )
          : null,
    );
  }
}
