{{--
    Avancement d'un signalement en cinq états (Signalé, En cours, Résolu,
    Non résolu, Rejeté), présenté comme dans les applications mobiles : une
    pastille par étape reliée par un rail vertical rempli jusqu'à l'étape
    atteinte. Données : App\Support\AvancementSignalement::pour().
--}}
@php
    $couleurs = ['SIGNALE' => '#D93025', 'EN COURS' => '#E37400', 'ENLEVE' => '#188038', 'NON RESOLU' => '#C5221F', 'REJETE' => '#5F6368'];
    $etapes = \App\Support\AvancementSignalement::pour($carPosition, \App\Support\HistoriqueSignalement::pour($carPosition));
@endphp
<style>
    .avc { list-style:none; margin:0; padding:0; }
    .avc-etape { position:relative; display:flex; gap:14px; padding-bottom:22px; }
    .avc-etape:last-child { padding-bottom:0; }
    .avc-rail { position:absolute; left:15px; top:34px; bottom:2px; width:4px; border-radius:2px; background:#e1e8e4; overflow:hidden; }
    .avc-rail span { display:block; width:100%; height:0; border-radius:2px; animation:avc-glisse .8s ease-out forwards; }
    .avc-etape:last-child .avc-rail { display:none; }
    .avc-pastille { flex:0 0 34px; width:34px; height:34px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff; font-weight:800; border:2px solid #e1e8e4; background:#fff; z-index:1; }
    .avc-actuel .avc-pastille { box-shadow:0 0 0 5px rgba(0,0,0,.06); }
    .avc-titre { font-weight:800; color:#15201a; }
    .avc-a_venir .avc-titre, .avc-saute .avc-titre { color:#5f6b65; font-weight:600; }
    .avc-saute .avc-titre { text-decoration:line-through; }
    .avc-detail { color:#5f6b65; font-size:14px; }
    .avc-date { color:#5f6b65; font-size:13px; }
    .avc-badge { font-size:11px; font-weight:700; border-radius:8px; padding:2px 7px; margin-left:6px; }
    @keyframes avc-glisse { to { height:100%; } }
</style>
<ol class="avc">
    @foreach ($etapes as $i => $etape)
        @php
            $couleur = $couleurs[$etape['etat']] ?? '#5f6b65';
            $atteinte = in_array($etape['statut'], ['fait', 'actuel'], true);
            $suivante = $etapes[$i + 1] ?? null;
            $apres = $etapes[$i + 2] ?? null;
            $railRempli = $suivante && (in_array($suivante['statut'], ['fait', 'actuel'], true)
                || ($suivante['statut'] === 'saute' && $apres && in_array($apres['statut'], ['fait', 'actuel'], true)));
            $cible = $suivante ? ($suivante['statut'] === 'saute' && $apres ? $apres : $suivante) : null;
        @endphp
        <li class="avc-etape avc-{{ $etape['statut'] }}">
            <div class="avc-rail">@if ($railRempli)<span style="background:{{ $couleurs[$cible['etat']] ?? '#5f6b65' }}"></span>@endif</div>
            <div class="avc-pastille" style="{{ $atteinte ? "background:$couleur;border-color:$couleur" : '' }}">
                @if ($etape['statut'] === 'saute') –
                @elseif ($etape['statut'] === 'actuel') ●
                @elseif ($etape['etat'] === 'REJETE') ✕
                @elseif ($etape['etat'] === 'NON RESOLU') !
                @elseif ($atteinte) ✓
                @endif
            </div>
            <div>
                <div class="avc-titre">
                    {{ $etape['libelle'] }}
                    @if ($etape['statut'] === 'actuel')
                        <span class="avc-badge" style="background:{{ $couleur }}1f;color:{{ $couleur }}">Étape actuelle</span>
                    @endif
                </div>
                @if ($etape['statut'] === 'saute')
                    <div class="avc-detail">Étape non atteinte</div>
                @elseif (!empty($etape['detail']))
                    <div class="avc-detail">{{ $etape['detail'] }}</div>
                @endif
                @if ($atteinte && !empty($etape['date']))
                    <div class="avc-date">{{ $etape['date'] }}</div>
                @endif
            </div>
        </li>
    @endforeach
</ol>
