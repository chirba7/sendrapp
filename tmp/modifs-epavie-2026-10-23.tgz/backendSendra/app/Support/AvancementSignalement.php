<?php

namespace App\Support;

use App\Models\CarPosition;
use Carbon\Carbon;

/**
 * Avancement d'un signalement exprimé avec les cinq états affichés partout
 * (applications et back-office) : Signalé → En cours → Résolu, ou une des
 * deux autres issues, Non résolu ou Rejeté.
 *
 * Calculé ici une seule fois pour que les deux applications affichent
 * exactement les mêmes étapes, avec les mêmes dates.
 */
class AvancementSignalement
{
    public const LIBELLES = [
        'SIGNALE' => 'Signalé',
        'EN COURS' => 'En cours',
        'ENLEVE' => 'Résolu',
        'NON RESOLU' => 'Non résolu',
        'REJETE' => 'Rejeté',
    ];

    /** État affiché : « NON RESOLU » est déduit du constat de non-enlèvement. */
    public static function etatAffiche(CarPosition $s): string
    {
        if ($s->non_removed_at && !in_array($s->etat, ['ENLEVE', 'REJETE'], true)) {
            return 'NON RESOLU';
        }

        return $s->etat ?: 'SIGNALE';
    }

    /**
     * Trois étapes : Signalé, En cours, puis l'issue (Résolu par défaut tant que
     * le dossier n'est pas clos). Chaque étape porte son statut :
     * `fait`, `actuel` ou `a_venir`, et sa date quand elle est connue.
     *
     * @param  array<int, array<string, mixed>>  $historique  sortie de HistoriqueSignalement::pour()
     */
    public static function pour(CarPosition $s, array $historique = []): array
    {
        $etat = self::etatAffiche($s);
        $date = function (string $event) use ($historique) {
            foreach (array_reverse($historique) as $ligne) {
                if (($ligne['event'] ?? null) === $event) {
                    return self::iso($ligne['date'] ?? null);
                }
            }

            return null;
        };

        $signale = [
            'etat' => 'SIGNALE',
            'libelle' => self::LIBELLES['SIGNALE'],
            'detail' => $s->soumis_approbation_at
                ? 'Constatation transmise pour approbation'
                : ($s->agent_id ? 'Pris en charge par un agent' : 'Signalement reçu'),
            'date' => $date('cree') ?? self::iso($s->created_at),
        ];
        $enCours = [
            'etat' => 'EN COURS',
            'libelle' => self::LIBELLES['EN COURS'],
            'detail' => 'Approuvé, enlèvement à venir',
            'date' => $date('approuve'),
        ];

        switch ($etat) {
            case 'REJETE':
                $issue = ['etat' => 'REJETE', 'detail' => $s->motife_approbation ?: 'Refusé par l’autorité', 'date' => $date('rejete') ?? self::iso($s->updated_at)];
                break;
            case 'NON RESOLU':
                $issue = ['etat' => 'NON RESOLU', 'detail' => $s->non_removal_reason ?: 'Véhicule non enlevé', 'date' => self::iso($s->non_removed_at)];
                break;
            case 'ENLEVE':
                $issue = ['etat' => 'ENLEVE', 'detail' => 'Véhicule enlevé', 'date' => $date('enleve') ?? self::iso($s->date_enlevement) ?? self::iso($s->updated_at)];
                break;
            default:
                $issue = ['etat' => 'ENLEVE', 'detail' => 'Enlèvement du véhicule', 'date' => null];
        }
        $issue['libelle'] = self::LIBELLES[$issue['etat']];

        // Un refus peut intervenir directement après le signalement : l'étape
        // « En cours » n'a alors jamais eu lieu.
        $enCoursAtteint = in_array($etat, ['EN COURS', 'ENLEVE', 'NON RESOLU'], true);
        $clos = in_array($etat, ['ENLEVE', 'NON RESOLU', 'REJETE'], true);

        $signale['statut'] = ($enCoursAtteint || $clos) ? 'fait' : 'actuel';
        $enCours['statut'] = $clos ? ($enCoursAtteint ? 'fait' : 'saute') : ($enCoursAtteint ? 'actuel' : 'a_venir');
        if (!$enCoursAtteint) {
            $enCours['date'] = null;
        }
        $issue['statut'] = $clos ? 'fait' : 'a_venir';

        return [$signale, $enCours, $issue];
    }

    private static function iso($valeur): ?string
    {
        if (empty($valeur)) {
            return null;
        }
        try {
            return Carbon::parse($valeur)->format('d/m/Y à H\hi');
        } catch (\Throwable) {
            return null;
        }
    }
}
