<?php

use App\Http\Controllers\ApprobationController;
use App\Http\Controllers\AuthControllerApi;
use App\Http\Controllers\CarPositionController;
use App\Http\Controllers\DommagesController;
use App\Http\Controllers\EnlevementController;
use App\Http\Controllers\InfractionController;
use App\Http\Controllers\MissionController;
use App\Http\Controllers\SignalementAgentController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\VehiculeController;
use App\Http\Controllers\SMSController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Public routes (No authentication required)
Route::group([
    'middleware' => 'api',
], function () {
    // Endpoint de découverte réseau : l'app mobile scanne le sous-réseau
    // local pour retrouver l'IP du backend Docker (qui change à chaque bail
    // DHCP) — cette signature lui permet de distinguer ce serveur d'un
    // autre appareil qui répondrait par hasard sur le port 8000.
    Route::get('/ping', fn () => response()->json(['app' => 'sendra-backend']));

    // Authentication
    Route::post('/login', [AuthControllerApi::class, 'login'])->name('login');
    Route::post('/verify-code', [AuthControllerApi::class, 'verifyCode']);
    Route::post('/register', [AuthControllerApi::class, 'register']);
    Route::post('/pointage/inscription', [\App\Http\Controllers\AttendanceEnrollmentController::class, 'register'])
        ->middleware('throttle:5,1');

    // Correction API-C-5 : ces deux routes n'ont plus de clé statique en
    // entrée (extractible de l'app mobile, donc sans valeur de protection
    // réelle) — le rate-limiting protège maintenant contre l'énumération.
    Route::middleware('throttle:10,1')->group(function () {
        Route::post('/send-verification-code', [AuthControllerApi::class, 'sendVerificationCode']);
        Route::post('/check-phone', [AuthControllerApi::class, 'checkPhone']);
    });

    // Mot de passe oublié : nécessite un code déjà vérifié via
    // /verify-code pour ce numéro (voir resetPassword()).
    Route::post('/reset-password', [AuthControllerApi::class, 'resetPassword']);

    // Procès-verbal signé : ouvert par le navigateur du téléphone, qui n'a
    // pas le jeton JWT — protégé par un lien signé valable 30 minutes.
    Route::get('/pv/{carPosition}/telecharger', [SignalementAgentController::class, 'telechargerPv'])
        ->middleware('signed:relative')
        ->name('pv.telecharger');
});

// Protected routes (Authentication required with JWT)
Route::middleware('jwt.auth')->group(function () {
    Route::prefix('pointage')->group(function () {
        Route::get('/statut', [\App\Http\Controllers\AttendanceEnrollmentController::class, 'status']);
        Route::post('/adhesion', [\App\Http\Controllers\AttendanceEnrollmentController::class, 'join'])->middleware('throttle:5,1');
        Route::post('/appareil/enregistrer', [\App\Http\Controllers\AttendanceDeviceController::class, 'register'])->middleware('throttle:3,1');
        Route::post('/appareil/defi', [\App\Http\Controllers\AttendanceDeviceController::class, 'challenge'])->middleware('throttle:10,1');
        Route::get('/configuration', [\App\Http\Controllers\AttendanceController::class, 'configuration']);
        Route::get('/historique', [\App\Http\Controllers\AttendanceController::class, 'history']);
        Route::post('/pointer', [\App\Http\Controllers\AttendanceController::class, 'store'])->middleware('throttle:10,1');
    });
    // Authentication-related routes
    Route::post('/logout', [AuthControllerApi::class, 'logout']);
    Route::post('/refresh', [AuthControllerApi::class, 'refresh']);
    Route::post('/me', [AuthControllerApi::class, 'me']);
    Route::post('/profile', [AuthControllerApi::class, 'updateProfile']);
    Route::post('/delete-user', [AuthControllerApi::class, 'deleteUser']);
    Route::put('/change-password', [AuthControllerApi::class, 'changePassword']);

    // Signalement routes ouvertes à tout citoyen connecté (auto-scopées à
    // son propre compte côté contrôleur : store()/voirSignalements()).
    Route::get('/voirSignalements', [CarPositionController::class, 'voirSignalements']);
    Route::post('/faireSignalement', [CarPositionController::class, 'store']);
    // Signalements des autres citoyens (liste et carte), en données réduites.
    Route::get('/signalementsCommunaute', [CarPositionController::class, 'signalementsCommunaute']);

    // Correction API-C-3 : routes "métier" réservées au personnel
    // (Admin=1, Agent=2, Autorité commune=3, Autorité préfecture=4).
    // Auparavant accessibles à n'importe quel citoyen auto-inscrit (role_id=5).
    Route::middleware('role:1,2,3,4')->group(function () {
        Route::get('/listerSignalements', [CarPositionController::class, 'listerSignalements']);
        Route::get('/listerSignalement/{carPosition}', [CarPositionController::class, 'listerSignalement']);
        Route::delete('/supprimerSignalement/{carPosition}', [CarPositionController::class, 'destroy']);

        // Vehicule routes
        Route::put('/vehicule/{carPosition}', [VehiculeController::class, 'update']);
        Route::get('/vehicule/{carPosition}', [VehiculeController::class, 'show']);
        Route::get('/vehicule', [VehiculeController::class, 'index']);

        // Infraction routes
        Route::get('/infraction', [InfractionController::class, 'index']);
        Route::get('/infraction/{carPosition}', [InfractionController::class, 'show']);
        Route::put('/infraction/{carPosition}', [InfractionController::class, 'update']);

        // Enlevement routes
        Route::put('/enlevement/{carPosition}', [EnlevementController::class, 'ajouterEnlevement']);
        Route::get('/enlevement/{carPosition}', [EnlevementController::class, 'obtenirEnlevement']);

        // Dommages routes
        Route::put('/enregistrerDommages/{carPosition}', [DommagesController::class, 'enregistrerDommages']);
        Route::post('/constatation/{carPosition}/photos', [DommagesController::class, 'ajouterPhoto']);
        Route::get('/voirDommages/{vehicleId}', [DommagesController::class, 'voirDommages']);

        // Statistiques
        Route::get('/statistiques', [CarPositionController::class, 'statistiques']);
    });

    // Agent (et administrateur) : prise en charge exclusive, photos de
    // constatation, procès-verbal.
    Route::middleware('role:1,2')->group(function () {
        Route::post('/signalements/{carPosition}/prise-en-charge', [SignalementAgentController::class, 'prendreEnCharge']);
        Route::delete('/signalements/{carPosition}/prise-en-charge', [SignalementAgentController::class, 'liberer']);
        Route::delete('/constatation/{carPosition}/photos/{photo}', [SignalementAgentController::class, 'supprimerPhoto']);
        Route::post('/signalements/{carPosition}/pv/signer', [SignalementAgentController::class, 'signerPv']);
        Route::get('/signalements/{carPosition}/pv', [SignalementAgentController::class, 'lienPv']);
    });

    Route::middleware('role:2')->group(function () {
        Route::get('/missions', [MissionController::class, 'index']);
        Route::get('/missions/{mission}', [MissionController::class, 'show']);
        Route::post('/missions/{mission}/pointer', [MissionController::class, 'checkIn'])
            ->middleware('throttle:10,1');
        Route::post('/missions/{mission}/enlevements', [MissionController::class, 'storeRemoval']);
        Route::post('/missions/{mission}/vehicules/{vehicle}/non-enleve', [MissionController::class, 'markNotRemoved']);
        Route::post('/missions/{mission}/enlevements/{removal}/modifier', [MissionController::class, 'updateRemoval']);
        Route::post('/missions/{mission}/camions/{truck}/destination', [MissionController::class, 'storeTruckDestination']);
        Route::post('/missions/{mission}/valider-enlevement', [MissionController::class, 'validateRemoval']);
        Route::post('/missions/{mission}/pointer-reception', [MissionController::class, 'checkInReception'])->middleware('throttle:10,1');
        Route::post('/missions/{mission}/receptions/{removal}', [MissionController::class, 'storeReception']);
        Route::post('/missions/{mission}/terminer', [MissionController::class, 'completeMission']);
    });

    // Correction ACL : l'approbation est réservée à Admin/Autorité commune/
    // Autorité préfecture — le spec fonctionnel (AUDIT_SENDRA.md §1.1)
    // exclut explicitement l'Agent ("traite les signalements, pas d'accès
    // à l'approbation"), qui pouvait pourtant approuver comme n'importe
    // quel autre rôle staff avant ce correctif.
    Route::middleware('role:1,3,4')->group(function () {
        Route::put('/soumettreApprobation/{carPosition}', [ApprobationController::class, 'soumettreApprobation']);
        Route::get('/motifsApprobation/{carPosition}', [ApprobationController::class, 'motifsApprobation']);
    });
});
