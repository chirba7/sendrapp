import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:walletium/views/screens/vehicule_screen.dart';
import '../../utils/session.dart';
import '../../utils/strings.dart';
import '../../utils/sendra_theme.dart';
import '../../widgets/others/galerie_photos_signalement.dart';
import 'carto.dart';
import 'dommages_screen.dart';
import 'informationBase_screen.dart';
import 'infraction_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DepositMoneyDetailsScreen extends StatefulWidget {
  DepositMoneyDetailsScreen({Key? key}) : super(key: key);

  @override
  _DepositMoneyDetailsScreenState createState() =>
      _DepositMoneyDetailsScreenState();
}

class _DepositMoneyDetailsScreenState extends State<DepositMoneyDetailsScreen> {
  late Future<Map<String, dynamic>> signalementDataFuture = Future.value({});
  bool isLoading = true;
  Map<String, dynamic> signalementData = {};
  bool _isStaff = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      fetchSignalementData();
    });
  }

  Future<Map<String, dynamic>> fetchSignalementDetails(
      int signalementId) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token');
    final url = Strings.apiURI + 'listerSignalement/$signalementId';
    final headers = {'Authorization': 'Bearer $token'};

    final response = await http.get(Uri.parse(url), headers: headers);
    if (response.statusCode == 200) {
      final jsonResponse = jsonDecode(response.body);
      if (jsonResponse.containsKey('data') && jsonResponse['data'].isNotEmpty) {
        return jsonResponse['data'][0];
      } else {
        throw Exception('Aucune donnée trouvée pour ce signalement');
      }
    } else {
      throw Exception('Erreur de chargement des détails du signalement');
    }
  }

  Future<void> fetchSignalementData() async {
    try {
      _isStaff = await Session.isStaff();
      final args = ModalRoute.of(context)!.settings.arguments;

      if (args is Map) {
        // Actualiser depuis l’API citoyenne pour refléter la décision de l’autorité.
        final initial = Map<String, dynamic>.from(args);
        signalementData = initial;
        final prefs = await SharedPreferences.getInstance();
        final token = prefs.getString('token');
        if (token != null) {
          try {
            final response = await http.get(
              Uri.parse('${Strings.apiURI}voirSignalements'),
              headers: {'Authorization': 'Bearer $token'},
            );
            if (response.statusCode == 200) {
              final decoded = jsonDecode(response.body);
              final items = decoded is List ? decoded
                  : (decoded['data'] as List<dynamic>? ?? const []);
              for (final item in items) {
                if (item['signalementId']?.toString() ==
                    initial['signalementId']?.toString()) {
                  signalementData = Map<String, dynamic>.from(item);
                  break;
                }
              }
            }
          } catch (_) {
            // La dernière version connue reste consultable hors ligne.
          }
        }
        signalementDataFuture = Future.value(signalementData);
      } else {
        // Reçu depuis un écran staff (liste globale, redirection après
        // enlèvement/dommages) : simple ID, on va chercher le détail à jour.
        final signalementId = int.parse(args.toString());
        signalementDataFuture = fetchSignalementDetails(signalementId);
        signalementData = await signalementDataFuture;
      }

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      print('Erreur: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _showRouteToSignalement() async {
    try {
      // Vérifier si les services de localisation sont activés
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        // Si les services de localisation ne sont pas activés, demandez à l'utilisateur de les activer
        _showLocationServiceDialog();
        return;
      }

      // Vérifier et demander la permission de localisation si nécessaire
      LocationPermission permission = await Geolocator.checkPermission();

      // Si les permissions ne sont pas accordées, demandez la permission
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        // Si la permission est refusée ou refusée définitivement, demander la permission
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied ||
            permission == LocationPermission.deniedForever) {
          // Si l'utilisateur refuse toujours la permission, affichez un message
          _showPermissionDeniedDialog();
          return;
        }
      }
      // Récupérer la position du signalement
      double signalementLat =
          double.parse(signalementData['latitude'].toString());
      double signalementLng =
          double.parse(signalementData['longitude'].toString());

      // Rediriger vers NavigationScreen avec les coordonnées du signalement
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => NavigationScreen(
            latitude: signalementLat,
            longitude: signalementLng,
          ),
        ),
      );
      /*
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => MapScreen(
            currentLocation: LatLng(currentPosition.latitude, currentPosition.longitude),
            destinationLocation: LatLng(signalementLat, signalementLng),
          ),
        ),
      );
       */
    } catch (e) {
      print('Erreur lors de la récupération de la position : $e');
    }
  }

// Affiche un message demandant à l'utilisateur d'activer les services de localisation
  void _showLocationServiceDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Services de localisation désactivés'),
          content: Text(
              'Veuillez activer les services de localisation pour continuer.'),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

// Affiche un message informant l'utilisateur que l'autorisation de localisation est nécessaire
  void _showPermissionDeniedDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              Icon(Icons.error,
                  color: Colors.orange, size: 32), // Icône d'erreur plus grande
              SizedBox(width: 15),
              Expanded(
                child: Text(
                  'Autorisation de localisation requise !',
                  style: TextStyle(
                    color: Colors.orange,
                    fontWeight: FontWeight.bold,
                    fontSize:
                        18, // Augmenter la taille de la police pour une meilleure visibilité
                  ),
                  softWrap: true, // Permet au texte de passer à la ligne
                  overflow:
                      TextOverflow.visible, // Pas d'ellipses, texte complet
                ),
              ),
            ],
          ),
          content: Padding(
            padding: const EdgeInsets.symmetric(
                vertical: 8.0), // Ajout d'un peu de padding autour du texte
            child: Text(
              'Pour afficher l\'itinéraire, veuillez activer la localisation dans les paramètres de votre appareil.',
              style: TextStyle(
                  fontSize: 16, height: 1.5), // Augmentation de la lisibilité
              softWrap: true, // Permet au texte de passer à la ligne
              textAlign: TextAlign
                  .center, // Centrer le texte pour une meilleure présentation
            ),
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(
                12), // Coins arrondis plus marqués pour un effet plus moderne
          ),
          elevation: 6, // Ajouter une ombre pour un effet flottant
          backgroundColor:
              Colors.white, // Fond blanc pour un contraste plus marqué
          actionsPadding: EdgeInsets.symmetric(
              horizontal: 20, vertical: 10), // Espacement des boutons
          actions: <Widget>[
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.blue, // Couleur du texte
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(8), // Coins arrondis du bouton
                ),
                backgroundColor: Colors.blue
                    .withValues(alpha: 0.1), // Fond léger pour le bouton
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                    vertical: 10,
                    horizontal: 20), // Un peu de padding pour le bouton
                child: Text(
                  'OK',
                  style: TextStyle(fontSize: 16), // Taille de police du bouton
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Détail du signalement'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => Navigator.of(context).pop(),
        ),
        backgroundColor: Colors.white,
        foregroundColor: SendraTheme.ink,
        elevation: 0,
      ),
      body: SafeArea(
        top: false,
        child: isLoading
            ? _buildLoading()
            : FutureBuilder<Map<String, dynamic>>(
                future: signalementDataFuture,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return _buildLoading();
                  } else if (snapshot.hasError) {
                    print('Erreur: ${snapshot.error}');
                    return _buildError();
                  } else if (snapshot.hasData) {
                    return _buildContent(snapshot.data!);
                  } else {
                    return _buildError();
                  }
                },
              ),
      ),
    );
  }

  Widget _buildContent(Map<String, dynamic> signalementData) {
    final isApproved = signalementData['is_approve'] == true;
    final isResolved = signalementData['etat']?.toString() == 'ENLEVE';
    // Une fois approuvé (et tant que ce n'est pas résolu), la constatation
    // (infos/véhicule/infraction/dommages) n'est plus l'action prioritaire —
    // elle est repliée dans un seul bouton dépliable, et l'enlèvement (la
    // vraie prochaine étape) est mis en relief. Un signalement résolu
    // retrouve l'affichage à plat des 5 items, comme avant approbation.
    final grouped = _isStaff && isApproved && !isResolved;
    final submitted = signalementData['dommages_saisis'] == true;

    return RefreshIndicator(
      onRefresh: fetchSignalementData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
              child: GaleriePhotosSignalement(
                signalementData: signalementData,
                hauteur: 220,
              ),
            ),
            _workflowHeader(signalementData),
            _localisationButton(),
            if (!grouped && !submitted) _menuItem('Informations de base', signalementData),
            // Le workflow métier (véhicule, infraction, dommages, enlèvement)
            // est réservé au staff côté API (role:1,2,3,4) — masqué pour un
            // citoyen, qui n'a qu'une vue de suivi de son signalement.
            if (_isStaff) ...[
              if (submitted) ...[
                _submittedRecap(signalementData),
                if (isApproved && !isResolved) _missionAssignmentCard(),
              ] else if (!isApproved) ...[
                _menuItem('Véhicule', signalementData),
                _menuItem('Infraction', signalementData),
                _menuItem('Dommages', signalementData),
                if (signalementData['dommages_saisis'] == true)
                  _approvalStatus(signalementData['etat']?.toString()),
              ] else if (grouped) ...[
                _constatationGroup(signalementData),
                _missionAssignmentCard(),
              ] else ...[
                _menuItem('Véhicule', signalementData),
                _menuItem('Infraction', signalementData),
                _menuItem('Dommages', signalementData),
              ],
            ] else
              _citizenStatusCard(signalementData),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _submittedRecap(Map<String, dynamic> data) {
    final fields = <String, String>{
      'Plaque': data['numero_vehicule']?.toString() ?? 'Non renseignée',
      'Véhicule': '${data['marque'] ?? ''} ${data['model'] ?? ''}'.trim(),
      'Type': data['type']?.toString() ?? '',
      'Catégorie': data['categorie']?.toString() ?? '',
      'État général': data['entretien']?.toString() ?? '',
      'Adresse': data['adresse_precise']?.toString() ?? '',
      'Infraction': data['motif_infraction']?.toString() ?? '',
      'Explication': data['explication_infraction']?.toString() ?? '',
      'Pièces manquantes': data['pieces_manquantes']?.toString() ?? '',
    };
    final photos = (data['photos_agent'] as List<dynamic>? ?? const []);
    return Card(
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Récapitulatif de la constatation',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const Text('Transmise pour approbation · lecture seule'),
          const SizedBox(height: 12),
          for (final entry in fields.entries)
            if (entry.value.isNotEmpty) Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text('${entry.key} : ${entry.value}'),
            ),
          if (photos.isNotEmpty) ...[
            const Text('Photos de l’agent', style: TextStyle(fontWeight: FontWeight.bold)),
            Wrap(spacing: 8, children: photos.map((photo) => Image.network(
              photo['url'].toString(), width: 80, height: 80, fit: BoxFit.cover,
              cacheWidth: 240,
            )).toList()),
          ],
          _approvalStatus(data['etat']?.toString()),
        ]),
      ),
    );
  }

  Widget _missionAssignmentCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: const Color(0xFFEAF3FF),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFB8D5F5)),
        ),
        child: const Row(children: [
          SizedBox(
            width: 50,
            height: 50,
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.all(Radius.circular(14)),
              ),
              child: Icon(Icons.assignment_turned_in_outlined,
                  color: Color(0xFF2468A2), size: 27),
            ),
          ),
          SizedBox(width: 14),
          Expanded(
              child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Prêt pour une mission',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
              SizedBox(height: 4),
              Text(
                  'L’enlèvement se réalise désormais depuis une mission affectée.',
                  style: TextStyle(color: SendraTheme.muted)),
            ],
          )),
        ]),
      ),
    );
  }

  Widget _constatationGroup(Map<String, dynamic> signalementData) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Card(
        elevation: 0,
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: SendraTheme.border),
        ),
        color: Colors.white,
        child: Theme(
          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
          child: ExpansionTile(
            tilePadding: const EdgeInsets.symmetric(horizontal: 16),
            leading: Container(
              width: 44,
              height: 44,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFFE8F5ED),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.fact_check_rounded,
                  color: SendraTheme.green, size: 24),
            ),
            title: const Text(
              'Constatation',
              style: TextStyle(
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                  color: SendraTheme.ink),
            ),
            subtitle: const Text(
              'Informations, véhicule, infraction, dommages',
              style: TextStyle(color: SendraTheme.muted, fontSize: 12.5),
            ),
            childrenPadding: const EdgeInsets.only(bottom: 6),
            children: [
              _menuItem('Informations de base', signalementData),
              _menuItem('Véhicule', signalementData),
              _menuItem('Infraction', signalementData),
              _menuItem('Dommages', signalementData),
            ],
          ),
        ),
      ),
    );
  }

  Widget _workflowHeader(Map<String, dynamic> data) {
    final status = data['etat']?.toString() ?? 'SIGNALE';
    final color = status == 'ENLEVE'
        ? SendraTheme.green
        : status == 'EN COURS'
            ? SendraTheme.amber
            : Colors.red.shade600;
    final label = status == 'ENLEVE'
        ? 'Résolu'
        : status == 'NON RESOLU'
            ? 'Non résolu'
        : status == 'EN COURS'
            ? 'En cours'
            : status == 'REJETE'
                ? 'Rejeté'
                : 'À constater';
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: SendraTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
                decoration: BoxDecoration(
                  color: color.withValues(alpha: .11),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  label,
                  style: TextStyle(
                      color: color, fontWeight: FontWeight.w700, fontSize: 12),
                ),
              ),
              const Spacer(),
              Text(
                'N° ${data['signalementId'] ?? ''}',
                style: const TextStyle(
                    color: SendraTheme.muted, fontWeight: FontWeight.w600),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            data['titre']?.toString() ?? 'Signalement',
            style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 5),
          Row(
            children: [
              const Icon(Icons.location_on_outlined,
                  size: 18, color: SendraTheme.green),
              const SizedBox(width: 5),
              Expanded(
                child: Text(
                  data['commune']?.toString() ?? 'Commune non renseignée',
                  style: const TextStyle(color: SendraTheme.muted),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _citizenStatusCard(Map<String, dynamic> data) {
    final status = data['etat']?.toString() ?? 'SIGNALE';
    final submitted = data['dommages_saisis'] == true;
    final approved = data['is_approve'] == true;
    final rejected = status == 'REJETE';
    final steps = <String>[
      'Signalement reçu',
      'Constatation par un agent',
      'Transmis pour approbation',
      rejected ? 'Refusé par l’autorité' : 'Approuvé par l’autorité',
      status == 'NON RESOLU' ? 'Véhicule non enlevé' : 'Enlèvement du véhicule',
    ];
    // Un refus de l'autorité clôture le dossier : l'étape « Enlèvement du
    // véhicule » est complétée automatiquement, en rouge.
    final reached = status == 'ENLEVE' || status == 'NON RESOLU' || rejected
        ? 5
        : approved ? 4 : submitted ? 3
        : status == 'EN COURS' ? 2 : 1;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Avancement du signalement',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            const SizedBox(height: 10),
            for (var i = 0; i < steps.length; i++)
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(
                    status == 'NON RESOLU' && i == 4
                        ? Icons.report_problem_outlined
                        : i < reached ? Icons.check_circle : Icons.circle_outlined,
                    color: status == 'NON RESOLU' && i == 4
                        ? Colors.deepOrange
                        : i < reached
                            ? (rejected && i >= 3
                                ? SendraTheme.statusSignale
                                : SendraTheme.statusResolu)
                            : SendraTheme.border),
                title: Text(steps[i]),
                subtitle: rejected && i == 4
                    ? const Text('Clôturé suite au refus de l’autorité')
                    : null,
              ),
            if (rejected && data['motif_approbation'] != null)
              Text('Motif : ${data['motif_approbation']}'),
            if (status == 'NON RESOLU')
              Text('Motif de non-enlèvement : ${data['non_removal_reason'] ?? 'Non renseigné'}'),
            const Text('Faites glisser vers le bas pour actualiser.',
                style: TextStyle(color: SendraTheme.muted)),
          ],
        ),
      ),
    );
  }

  Widget _approvalStatus(String? etat) {
    final rejected = etat == 'REJETE';
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Card(
        color: rejected ? Colors.red.shade50 : Colors.orange.shade50,
        child: ListTile(
          leading: Icon(
            rejected ? Icons.cancel_outlined : Icons.hourglass_top,
            color: rejected ? Colors.red : Colors.orange.shade800,
          ),
          title: Text(
            rejected
                ? 'Demande d’approbation rejetée'
                : 'En attente d’approbation administrative',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          subtitle: Text(
            rejected
                ? 'L’enlèvement reste indisponible.'
                : 'Faites glisser la page vers le bas pour actualiser le statut.',
          ),
        ),
      ),
    );
  }

  Widget _localisationButton() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
      child: ElevatedButton.icon(
        onPressed: _showRouteToSignalement,
        icon: Icon(
          Icons.location_on,
          size: 22,
        ),
        label: Text(
          'Voir l\'itinéraire',
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: SendraTheme.green,
          foregroundColor:
              Colors.white, // Couleur du texte et de l'icône en blanc
          minimumSize: const Size(double.infinity, 52),
          textStyle: TextStyle(
              fontSize: 18.0,
              fontWeight: FontWeight.bold), // Texte plus lisible
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          elevation: 0,
          splashFactory:
              InkRipple.splashFactory, // Effet de splash plus dynamique
        ),
      ),
    );
  }

  Widget _menuItem(String title, [Map<String, dynamic>? signalementData]) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Card(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: SendraTheme.border),
        ),
        color: Colors.white, // Couleur de fond claire
        child: ListTile(
          contentPadding:
              EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
          leading: Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: _iconForTitle(title).$2.withValues(alpha: .12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(_iconForTitle(title).$1,
                color: _iconForTitle(title).$2, size: 24),
          ),
          title: Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.w700,
              fontSize: 16,
              color: SendraTheme.ink,
            ),
          ),
          trailing: const Icon(
            Icons.chevron_right_rounded,
            color: SendraTheme.muted,
          ),
          onTap: () async {
            final signalementId = signalementData?['signalementId'];
            if (title == 'Informations de base') {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => BasicInfoForm(
                  signalementData: signalementData!,
                ),
              ));
            } else if (title == 'Véhicule') {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) => VehicleForm(
                  signalementId: signalementId,
                ),
              ));
            } else if (title == 'Infraction') {
              Navigator.of(context).push(MaterialPageRoute(
                builder: (context) =>
                    InfractionForm(signalementId: signalementId),
              ));
            } else if (title == 'Dommages') {
              final updated =
                  await Navigator.of(context).push<bool>(MaterialPageRoute(
                builder: (context) => DommagesScreen(
                  signalementId: signalementId,
                ),
              ));
              if (updated == true && mounted) {
                await fetchSignalementData();
              }
            }
          },
        ),
      ),
    );
  }

  /// Icône et couleur de chaque étape de la constatation (remplace les
  /// emojis, dont le rendu variait selon les téléphones).
  (IconData, Color) _iconForTitle(String title) {
    return switch (title) {
      'Informations de base' => (Icons.description_rounded, const Color(0xFF1A73E8)),
      'Véhicule' => (Icons.directions_car_rounded, SendraTheme.green),
      'Infraction' => (Icons.gavel_rounded, const Color(0xFFE37400)),
      'Dommages' => (Icons.car_crash_rounded, const Color(0xFFD93025)),
      _ => (Icons.push_pin_rounded, SendraTheme.muted),
    };
  }

// Fonction pour obtenir l'icône correspondante en fonction du titre
  IconData _getIconForTitle(String title) {
    switch (title) {
      case 'Informations de base':
        return Icons
            .library_books; // Icône de livre ou de données (plus spécifique pour les informations)
      case 'Véhicule':
        return Icons
            .directions_car_filled; // Icône de voiture remplie (plus explicite)
      case 'Infraction':
        return Icons
            .report_problem; // Icône de rapport de problème (plus adapté aux infractions)
      case 'Dommages':
        return Icons.draw; // Icône de rapport pour dommages (plus approprié)
      //return Icons.report_problem;; // Icône de rapport pour dommages (plus approprié)
      default:
        return Icons.list; // Icône de liste générique pour un menu
    }
  }

  Widget _buildLoading() {
    return Center(
      child: CircularProgressIndicator(),
    );
  }

  Widget _buildError() {
    return Center(
      child: Text(
        'Échec du chargement des détails du signalement.',
        style: TextStyle(
          color: Colors.red,
          fontSize: 16.0,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
