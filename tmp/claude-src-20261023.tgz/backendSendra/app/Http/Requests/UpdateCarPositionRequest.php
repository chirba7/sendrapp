<?php

namespace App\Http\Requests;


use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateCarPositionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    /**
     * Un signalement envoyé pour approbation n'est plus modifiable par l'agent
     * (compte rendu de direction, § 04). Le refus est renvoyé AVANT la
     * validation des champs : sinon l'agent reçoit « erreur de validation »
     * au lieu de la vraie raison.
     */
    protected function prepareForValidation(): void
    {
        $carPosition = $this->route('carPosition');
        if ($carPosition && $carPosition->soumis_approbation_at) {
            throw new HttpResponseException(response()->json([
                'success' => false,
                'message' => "Ce signalement a été envoyé pour approbation : il n'est plus modifiable.",
                'soumis_le' => $carPosition->soumis_approbation_at,
            ], 423));
        }
    }

    public function rules(): array
    {
        return [
            'numero_vehicule' => 'required|string|max:255',
            'marque' => 'required|string|max:255',
            'type' => 'required|string|max:255',
            'vehicle_kind' => 'nullable|string|in:Voiture,Moto',
            'model' => 'required|string|max:255',
            'categorie' => 'required|string|max:255',
            'couleur' => 'required|string|max:255',
            'entretien' => 'required|string|in:BON,MOYEN,DEGRADE',
            'pays_etranger' => 'required|string|in:OUI,NON',
            'defaut_controle_technique' => 'nullable|boolean',
            'pneumatiques_manquantes' => 'nullable|boolean',
            'vehicule_immerge' => 'nullable|boolean',
            'defauts_techniques_irreversibles' => 'nullable|boolean',
            'vehicule_non_identifiable' => 'nullable|boolean',
            'vehicule_brule' => 'nullable|boolean',
            'chassis_non_reparable' => 'nullable|boolean',
	    'autre_situation' => 'nullable|string|max:500',
	    
        ];
    }
    public function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(response()->json([
            'success' => false,
            'status_code' => 422,
            'error' => true,
            'message' => 'erreur de validation',
            'errorList' => $validator->errors()
        ]));
    }
}
